'''
9. Вводятся три разных числа.
Найти, какое из них является средним (больше одного, но меньше другого).
'''
numbers = []

a = int(input('Введите первое число: '))
b = int(input('Введите второе число: '))
c = int(input('Введите третье число: '))

if a > b:
    if a < c:
        middle = a
    elif a > c:
        if b > c:
            middle = b
        else:
            middle = c
elif a < b:
    if a > c:
        middle = a
    elif a < c:
        if b < c:
            middle = b
        else:
            middle = c

print(f'Среднее число среди {a},{b},{c}: ', middle)









